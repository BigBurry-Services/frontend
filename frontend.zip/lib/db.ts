/**
 * This file is now a no-op as the application has migrated to JSON-based local storage.
 */
async function dbConnect() {
  return true;
}

export default dbConnect;
