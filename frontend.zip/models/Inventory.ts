import { JsonStorage } from "../lib/jsonStorage";

export interface IInventory {
  id: string;
  name: string;
  stock: number;
  unitPrice: number;
  batchNumber?: string;
  expiryDate?: Date;
  createdAt: Date;
  updatedAt: Date;
}

const Inventory = new JsonStorage<IInventory>("inventory");

export default Inventory;
